# AquaSafeTwin

**Risk-Aware Multimodal Digital Twin for Aquaculture: Agentic AI for Safe Decision Support**

> **Research prototype — work in progress.** This repository provides reproducible *offline* data auditing, forecasting baselines, and an illustrative independent action verifier. It is **not** a live digital twin, autonomous farm controller, validated animal-welfare system, or a claim of improved fish outcomes.

## Research questions

- **RQ1:** Does combining video-derived fish behaviour and water-quality data improve held-out forecasting relative to single-modality baselines?
- **RQ2:** How robust is the multimodal representation to missing, delayed, and unreliable observations?
- **RQ3:** Does an independent constraint checker reduce policy violations in an expert-designed offline decision benchmark?

## Status

| Component | Status |
|---|---|
| Paper draft (ACM anonymous review) | Draft, Sections 1–5; results placeholders |
| CSV integrity and timestamp audit | Implemented |
| Chronological persistence / water-only / video-only / multimodal baselines | Implemented; **not run on real data** |
| Demonstration scenario policy checker | Implemented; thresholds **illustrative only** |
| Real fish video feature extraction | Planned |
| Dataset alignment and provenance validation | Pending actual downloads |
| Risk benchmark with expert labels | Planned |
| Field deployment / action-effect validation | Not implemented |

## Repository layout

```text
AquaSafeTwin/
├── .github/workflows/tests.yml
├── README.md
├── LICENSE
├── CITATION.cff
├── .gitignore
├── pyproject.toml
├── requirements.txt
├── configs/experiment.example.yaml
├── data/README.md
├── data/raw/                   # ignored: never commit third-party data
├── data/processed/             # ignored
├── docs/REPRODUCIBILITY.md
├── docs/ROADMAP.md
├── docs/SAFETY_AND_ETHICS.md
├── experiments/
│   ├── audit_dataset.py
│   ├── make_demo_data.py
│   ├── run_baselines.py
│   └── evaluate_safety.py
├── src/aquasafetwin/safety.py
├── tests/test_safety.py
├── results/                    # ignored outputs
└── paper/                      # Overleaf ACM LaTeX source
```

## Setup

Requires Python 3.10+ and Git. From the repository root:

```bash
python -m venv .venv
source .venv/bin/activate             # Windows: .venv\\Scripts\\activate
python -m pip install -e . pytest matplotlib
python -m pytest -q
```

## Quickstart: **synthetic data only**

This checks that the pipeline runs. **Never cite the demo output as a real experiment.**

```bash
python experiments/make_demo_data.py
python experiments/audit_dataset.py --csv data/processed/SYNTHETIC_demo.csv
python experiments/run_baselines.py \
  --csv data/processed/SYNTHETIC_demo.csv \
  --timestamp timestamp --target dissolved_oxygen \
  --water temperature ph --video mean_speed dispersion \
  --lookback 6 --horizon 1 \
  --out results/SYNTHETIC_baselines.json
python experiments/evaluate_safety.py \
  --csv configs/ILLUSTRATIVE_scenarios.csv \
  --out results/ILLUSTRATIVE_safety.json
```

The forecasting code requires a **single already-synchronized CSV** with one row per regular sampling interval. It does **not** automatically synchronize original videos and sensors. `--horizon` and `--lookback` are measured in **rows**, not minutes. It uses complete-case windows and a chronological split with an embargo; a robust publication study will also need independent sessions/farms and confidence intervals.

## Real data: acquisition and attribution

Start by examining the publisher landing pages and recording licenses, version, timestamps, checksums, units, and the exact downloaded files. Do not treat repository metadata as proof that the files have been audited.

1. **Fish videos and water quality (Figshare+)**: https://doi.org/10.25452/figshare.plus.19653321.v2 — candidate primary synchronized source. Verify the corrected version and exact files before using.
2. **Tilapia-RAS (Zenodo)**: https://doi.org/10.5281/zenodo.17518786 — candidate external video/metadata source. Verify file-level licenses and whether water-quality measurements are per-clip or continuous.
3. **Fish feeding intensity (Zenodo)**: https://doi.org/10.5281/zenodo.12759731 — candidate supplemental visual/audio data, **not** automatically synchronized with source 1.
4. **Tilapia feeding images (Zenodo)**: https://doi.org/10.5281/zenodo.17355839 — candidate vision benchmark, **not** time-aligned with source 1.

**Data are not bundled in this repository.** Follow each data owner's terms. Never join measurements from different farms as if they were concurrent observations.

See [data/README.md](data/README.md) for the expected input schema and [docs/REPRODUCIBILITY.md](docs/REPRODUCIBILITY.md) for a publication-grade protocol.

## Safety model

`src/aquasafetwin/safety.py` is a transparent rule checker for offline methodological demonstration. The oxygen threshold is **a placeholder, not an approved welfare threshold**. Any use with live animals requires species-specific validation, expert approval, operator oversight, and independent equipment safety assessment. No actuator commands are implemented.

## Paper

The `paper/` directory contains the current ACM `acmart` anonymous-review manuscript source. Import it into Overleaf or compile using a LaTeX installation with `acmart` and BibTeX. Section 5 is a template until empirical results exist. Do not claim a completed study before real-data experiments and independent evaluation are done.

## Contributions and citation

See [CITATION.cff](CITATION.cff). The repository is under the MIT license **for original code only**; third-party datasets and publications retain their own licenses. Avoid public author-identifying links in double-blind submissions; use a separately anonymized artifact if the venue permits it.
