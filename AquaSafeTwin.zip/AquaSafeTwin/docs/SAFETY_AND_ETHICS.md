# Research safety and ethics

This is offline research software. Do not connect it to feeding, oxygenation, pumps, or other equipment. The policy thresholds are illustrative and must not be interpreted as husbandry advice. Model outputs are not evidence of improved animal welfare, mortality, or productivity. Human experts should establish species-, life-stage-, stocking-density-, and facility-specific constraints before any evaluation beyond offline replay. Respect dataset permissions, farm confidentiality, copyright, and double-blind review requirements.
