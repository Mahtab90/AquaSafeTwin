# Data specification and provenance

Do not commit raw videos, dataset archives, farm logs, or potentially sensitive footage. Record the original URL, version, license, retrieval date, SHA-256, species, site, recording device, units, timezone, clock offsets, and known limitations in a local data manifest.

## Expected synchronized CSV (one row per fixed interval)

| Column | Example | Meaning |
|---|---|---|
| `timestamp` | `2025-01-01T12:00:00Z` | UTC interval end / decision time |
| `dissolved_oxygen` | `7.1` | DO in mg/L; verify units in source |
| `temperature` | `19.2` | Water temperature in Celsius |
| `ph` | `7.5` | pH |
| `mean_speed` | `0.4` | Video-derived activity (define physical or normalized units) |
| `dispersion` | `0.7` | Video-derived group dispersion (define units) |

The sample column names are **proposed schema**, not guaranteed source dataset field names. Build a separate preprocessing adapter after inspecting the real files. Include per-modality missingness/quality masks. Never forward-fill future measurements, align by nearest future observation, or use video frames after the prediction decision time.

A minimum real-data audit must verify camera/sensor synchronization, sampling gaps, fish/tank identity, source timestamp corrections, and video train/test group separation.
