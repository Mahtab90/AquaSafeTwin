#!/usr/bin/env python3
"""Offline policy benchmark on manually curated CSV scenarios.
Columns: dissolved_oxygen_mg_l,sensor_valid,aerator_available,
behaviour_confidence,candidate_action,expert_action (optional).
"""
import argparse, csv, json
from pathlib import Path
from aquasafetwin.safety import Observation, verify

def flag(value):
    return str(value).strip().lower() in ('1', 'true', 'yes')

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--csv', required=True)
    p.add_argument('--out', default='results/safety.json')
    a=p.parse_args()
    rows=list(csv.DictReader(open(a.csv, newline='', encoding='utf-8')))
    if not rows: p.error('Empty scenario CSV')
    outputs=[]
    for row in rows:
        oxygen=row.get('dissolved_oxygen_mg_l','').strip()
        obs=Observation(float(oxygen) if oxygen else None,
            flag(row.get('sensor_valid','true')),
            flag(row.get('aerator_available','true')),
            float(row.get('behaviour_confidence') or 1.0))
        result=verify(row['candidate_action'],obs)
        result['candidate_action']=row['candidate_action']
        if row.get('expert_action'):
            result['expert_action']=row['expert_action']
            result['expert_agreement']=result['decision']==row['expert_action']
        outputs.append(result)
    summary={'n_scenarios':len(outputs),
             'rejection_rate':sum(not x['accepted'] for x in outputs)/len(outputs),
             'note':'Constraint rejection is NOT equivalent to improved fish welfare.',
             'decisions':outputs}
    labeled=[x for x in outputs if 'expert_agreement' in x]
    if labeled: summary['expert_agreement']=sum(x['expert_agreement'] for x in labeled)/len(labeled)
    out=Path(a.out); out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in summary.items() if k!='decisions'},indent=2))
if __name__=='__main__': main()
