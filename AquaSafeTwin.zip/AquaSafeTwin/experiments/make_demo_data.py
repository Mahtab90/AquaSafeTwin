#!/usr/bin/env python3
"""SYNTHETIC smoke-test data. Never use as empirical evidence in the paper."""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd

def main():
    p=argparse.ArgumentParser(); p.add_argument('--out',default='data/processed/SYNTHETIC_demo.csv'); a=p.parse_args()
    rng=np.random.default_rng(42); n=480; t=np.arange(n)
    temp=18+1.4*np.sin(t/60)+rng.normal(0,.12,n)
    ph=7.4+.12*np.sin(t/37)+rng.normal(0,.03,n)
    speed=.7+.15*np.sin(t/25)+rng.normal(0,.06,n)
    dispersion=.5+.08*np.sin(t/40)+rng.normal(0,.05,n)
    oxygen=7-.45*np.sin(t/60)-.18*(temp-18)+.10*speed+rng.normal(0,.06,n)
    df=pd.DataFrame({'timestamp':pd.date_range('2020-01-01',periods=n,freq='5min',tz='UTC'),
                     'dissolved_oxygen':oxygen,'temperature':temp,'ph':ph,
                     'mean_speed':speed,'dispersion':dispersion})
    out=Path(a.out); out.parent.mkdir(parents=True,exist_ok=True); df.to_csv(out,index=False)
    print(f'SYNTHETIC ONLY: {out} ({n} rows)')
if __name__=='__main__':main()
