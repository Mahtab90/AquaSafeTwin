# Roadmap

- [x] Repository skeleton and ACM manuscript draft
- [x] CSV audit and chronological ML baselines
- [x] Illustrative rule-based independent verifier and unit tests
- [ ] Obtain primary dataset and verify publisher version and license
- [ ] Build source-specific parsing, camera/sensor timestamp correction and aligned features
- [ ] Extract actual video motion/behaviour features; validate annotations
- [ ] Establish grouped multi-session evaluation and statistical intervals
- [ ] Train uncertainty-aware fusion model and run ablations
- [ ] Create expert-reviewed decision scenario set and policy constraints
- [ ] Evaluate risk-aware agent against rule-only and unconstrained agent
- [ ] Update results and abstract using measured evidence
- [ ] Produce anonymized conference artifact if submission policy allows
