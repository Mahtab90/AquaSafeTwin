#!/usr/bin/env python3
"""Causal water-only vs multimodal prediction; run on audited synchronized CSV.
Example: python experiments/run_baselines.py --csv data/aligned.csv --timestamp timestamp --target dissolved_oxygen --water temperature ph conductivity --video mean_speed dispersion --lookback 6 --horizon 1
Requires pandas numpy scikit-learn. No imputation from future observations.
"""
import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error

def main():
 p=argparse.ArgumentParser()
 p.add_argument('--csv',required=True); p.add_argument('--timestamp',default='timestamp'); p.add_argument('--target',required=True)
 p.add_argument('--water',nargs='*',default=[]); p.add_argument('--video',nargs='*',default=[])
 p.add_argument('--lookback',type=int,default=6); p.add_argument('--horizon',type=int,default=1)
 p.add_argument('--out',default='results/baselines.json'); a=p.parse_args()
 if not a.water or not a.video: p.error('Specify both --water and --video columns to test multimodal fusion')
 df=pd.read_csv(a.csv); needed=[a.timestamp,a.target]+a.water+a.video
 absent=[c for c in needed if c not in df.columns]
 if absent: p.error('Missing columns: '+', '.join(absent))
 df[a.timestamp]=pd.to_datetime(df[a.timestamp],utc=True,errors='coerce')
 if df[a.timestamp].isna().any(): p.error('Unparseable timestamps')
 if df[a.timestamp].duplicated().any(): p.error('Duplicate timestamps: audit/resample first')
 df=df.sort_values(a.timestamp).reset_index(drop=True)
 for c in [a.target]+a.water+a.video: df[c]=pd.to_numeric(df[c],errors='coerce')
 if a.lookback<1 or a.horizon<1: p.error('lookback and horizon must be positive')
 # Strict complete-case windows: no interpolation or backward fill.
 cols=list(dict.fromkeys([a.target]+a.water+a.video))
 features=[]; labels=[]; times=[]; indices=[]
 for i in range(a.lookback-1,len(df)-a.horizon):
  hist=df.loc[i-a.lookback+1:i,cols]
  y=df.loc[i+a.horizon,a.target]
  if hist.isna().any().any() or pd.isna(y): continue
  features.append({f'{c}_lag{lag}':float(df.loc[i-lag,c]) for c in cols for lag in range(a.lookback)})
  labels.append(float(y)); times.append(str(df.loc[i,a.timestamp])); indices.append(i)
 if len(labels)<80: p.error(f'Only {len(labels)} complete windows; need at least 80 for this baseline')
 X=pd.DataFrame(features); y=np.asarray(labels); n=len(y)
 # Chronological train, validation, test with embargo measured in eligible-window rows.
 embargo=a.lookback+a.horizon
 cut1=int(n*.6); cut2=int(n*.8)
 train=np.arange(0,max(0,cut1-embargo)); val=np.arange(cut1,min(n,cut2-embargo)); test=np.arange(cut2,n)
 if min(map(len,[train,val,test]))<15: p.error('Not enough non-overlapping chronological windows after embargo')
 configs={'water_only':list(dict.fromkeys([a.target]+a.water)), 'video_only':a.video, 'multimodal':cols}
 results={'data':{'n_rows':len(df),'complete_windows':n,'lookback_rows':a.lookback,'horizon_rows':a.horizon,'timestamps_utc':{'start':times[0],'end':times[-1]},'split_windows':{'train':len(train),'validation':len(val),'test':len(test)},'note':'Horizon and lookback are row-based. Confirm uniform sampling and physical time units in dataset audit.'},'models':{}}
 for name,used in configs.items():
  feature_names=[f'{c}_lag{lag}' for c in used for lag in range(a.lookback)]
  model=HistGradientBoostingRegressor(max_iter=150,max_leaf_nodes=15,l2_regularization=1.0,random_state=42)
  model.fit(X.iloc[train][feature_names],y[train]); pred=model.predict(X.iloc[test][feature_names])
  results['models'][name]={'mae':float(mean_absolute_error(y[test],pred)),'rmse':float(np.sqrt(mean_squared_error(y[test],pred))),'n_test':len(test)}
 persistence=X.iloc[test][f'{a.target}_lag0'].to_numpy()
 results['models']['persistence']={'mae':float(mean_absolute_error(y[test],persistence)),'rmse':float(np.sqrt(mean_squared_error(y[test],persistence))),'n_test':len(test)}
 results['limitations']=['No claims about intervention outcomes','Single held-out chronological test; multi-session block-bootstrap recommended','Complete-case filtering may bias towards well-observed periods','No sensor-video synchronization validation: requires separate provenance audit']
 out=Path(a.out); out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(results,indent=2)); print(json.dumps(results,indent=2))
if __name__=='__main__': main()
