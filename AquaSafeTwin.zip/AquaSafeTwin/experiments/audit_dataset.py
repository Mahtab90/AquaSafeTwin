#!/usr/bin/env python3
"""Report source-file hashes, missingness, timestamp issues. No source modification."""
import argparse,hashlib,json
from pathlib import Path
import pandas as pd
p=argparse.ArgumentParser(); p.add_argument('--csv',required=True); p.add_argument('--timestamp',default='timestamp'); p.add_argument('--out',default='results/audit.json'); a=p.parse_args()
f=Path(a.csv); h=hashlib.sha256()
with f.open('rb') as z:
 for block in iter(lambda:z.read(1024*1024),b''): h.update(block)
df=pd.read_csv(f); report={'file':str(f),'sha256':h.hexdigest(),'rows':len(df),'columns':df.columns.tolist(),'missing_count':df.isna().sum().to_dict()}
if a.timestamp in df:
 t=pd.to_datetime(df[a.timestamp],utc=True,errors='coerce'); sorted_t=t.dropna().sort_values()
 report['timestamps']={'invalid':int(t.isna().sum()),'duplicates':int(t.duplicated().sum()),'min_utc':str(sorted_t.min()),'max_utc':str(sorted_t.max()),'median_interval_seconds':float(sorted_t.diff().dt.total_seconds().median()) if len(sorted_t)>1 else None}
out=Path(a.out); out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(report,indent=2)); print(json.dumps(report,indent=2))
