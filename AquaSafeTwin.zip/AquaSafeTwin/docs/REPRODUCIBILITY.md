# Reproducibility protocol

1. **Acquire** primary archives directly from the published dataset record. Log URL, DOI, version, license, retrieval date and SHA-256. Do not silently substitute a newer version.
2. **Inspect** original timestamps, time zones, clock drift, duplicated measurements, missing periods, physical units, sampling intervals, and session/tank identifiers.
3. **Align causally**: aggregate sensor readings and video features only from observations available by decision time. Record tolerance, clock corrections and missingness masks.
4. **Split** by session/farm when possible; otherwise use chronological train/validation/test blocks and an embargo >= lookback + horizon. Fit transforms only on training data. Never split video frames randomly across the same recording.
5. **Forecast** persistence, water-only, video-only, and fused models using the same eligible timestamps. Report MAE/RMSE in physical units and horizon minutes; confidence intervals via blocked bootstrap when multiple independent blocks exist.
6. **Ablate** video, water variables, missingness masks, uncertainty estimation, and safety verifier. Include corrupt/absent sensor scenarios, reported separately from naturally occurring events.
7. **Evaluate decisions** only against independently authored and blinded expert scenarios with written policy and label adjudication. Report abstentions, invalid recommendations, constraint violation rate, and inter-rater agreement. No animal-welfare causal claim without intervention-outcome evidence.
8. **Release** pinned environment, seeds, hyperparameters, preprocessing adapters, model versions, hashes, split indices and anonymized results when permissions allow.

Current scripts are initial baselines, not the full protocol. `run_baselines.py` assumes regular sampling, complete-case windows, one CSV and a single chronological test. It does not establish camera-to-sensor alignment or cross-farm generalization.
