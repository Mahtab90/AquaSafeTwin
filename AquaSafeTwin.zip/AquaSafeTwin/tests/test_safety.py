from aquasafetwin.safety import Observation, verify, propose

def test_invalid_sensor_forces_inspection():
    x=verify('monitor',Observation(None,sensor_valid=False))
    assert not x['accepted'] and x['decision']=='inspect'

def test_unavailable_aerator_rejected():
    x=verify('increase_aeration',Observation(6.0,aerator_available=False))
    assert not x['accepted'] and x['decision']=='escalate'

def test_low_oxygen_monitor_rejected():
    assert not verify('monitor',Observation(3.0))['accepted']

def test_normal_monitor():
    assert verify(propose(Observation(7.0)),Observation(7.0))['accepted']

def test_unknown_action():
    assert not verify('dose_chemical',Observation(7.0))['accepted']
