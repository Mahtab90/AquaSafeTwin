"""Illustrative decision constraints. NOT validated biological safety limits.

A conservative, auditable policy for an *offline research benchmark*.
All thresholds must be defined by domain experts for a specific species/farm.
"""
from dataclasses import dataclass, asdict
from typing import Optional

ACTIONS = ('monitor', 'inspect', 'pause_feeding', 'increase_aeration', 'escalate')

@dataclass(frozen=True)
class Observation:
    dissolved_oxygen_mg_l: Optional[float]
    sensor_valid: bool = True
    aerator_available: bool = True
    behaviour_confidence: float = 1.0

@dataclass(frozen=True)
class Policy:
    # DEMONSTRATION values only; NOT husbandry recommendations.
    oxygen_warning_mg_l: float = 5.0
    minimum_behaviour_confidence: float = 0.6


def verify(action: str, obs: Observation, policy: Policy = Policy()) -> dict:
    """Return explainable decision. Never controls equipment."""
    if action not in ACTIONS:
        return {'accepted': False, 'decision': 'escalate', 'reason': 'unknown_action'}
    if not obs.sensor_valid or obs.dissolved_oxygen_mg_l is None:
        if action not in ('inspect', 'escalate'):
            return {'accepted': False, 'decision': 'inspect', 'reason': 'missing_or_invalid_oxygen'}
    if obs.behaviour_confidence < policy.minimum_behaviour_confidence and action == 'pause_feeding':
        return {'accepted': False, 'decision': 'inspect', 'reason': 'uncertain_behaviour'}
    if action == 'increase_aeration' and not obs.aerator_available:
        return {'accepted': False, 'decision': 'escalate', 'reason': 'aerator_unavailable'}
    if (obs.sensor_valid and obs.dissolved_oxygen_mg_l is not None
            and obs.dissolved_oxygen_mg_l < policy.oxygen_warning_mg_l
            and action == 'monitor'):
        return {'accepted': False, 'decision': 'escalate', 'reason': 'oxygen_warning_requires_review'}
    return {'accepted': True, 'decision': action, 'reason': 'constraints_passed'}


def propose(obs: Observation, policy: Policy = Policy()) -> str:
    """Simple deterministic baseline agent; replace only after benchmark design."""
    if not obs.sensor_valid or obs.dissolved_oxygen_mg_l is None:
        return 'inspect'
    if obs.dissolved_oxygen_mg_l < policy.oxygen_warning_mg_l:
        return 'escalate'
    return 'monitor'
